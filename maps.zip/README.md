# Maps-Widget
This is a simple Plugin for <a href="https://pagekit.com">Pagekit</a> based on the Service from Google Maps!
